const startBtn = document.getElementById('start-btn');
const stopBtn = document.getElementById('stop-btn');
const statusCard = document.getElementById('status-card');
const statusText = document.getElementById('status-text');
const questionField = document.getElementById('question');
const answerField = document.getElementById('answer');

const recipes = [
  {
    trigger: /pollo|sopa de pollo|caldo/i,
    response: 'Para una sopa de pollo clásica, sofríe cebolla y ajo, agrega zanahoria y apio, añade pollo y agua, hierve a fuego medio y sazona con sal, pimienta y hojas de laurel. Cocina hasta que el pollo esté tierno y sirve con cilantro fresco.'
  },
  {
    trigger: /pasta|espagueti|macarrones/i,
    response: 'Para cocinar pasta al dente, hierve agua con sal, agrega la pasta y cocina el tiempo indicado en el paquete. Escurre y mezcla con salsa de tomate, aceite de oliva y queso parmesano al gusto.'
  },
  {
    trigger: /ensalada|ensaladas/i,
    response: 'Para una ensalada fresca, combina hojas verdes, tomate, pepino y cebolla. Añade una vinagreta de aceite de oliva, vinagre balsámico, sal y pimienta. Puedes agregar aguacate o frutos secos para más sabor.'
  },
  {
    trigger: /tortilla|omelette|huevo/i,
    response: 'Para una tortilla esponjosa, bate huevos con una pizca de sal y pimienta. Cocina en una sartén caliente con mantequilla y añade queso, verduras o jamón según tu gusto. Dobla y sirve caliente.'
  }
];

const defaultResponse = 'Dime una pregunta de cocina, por ejemplo: ¿Cómo hago una sopa de pollo? Si quieres, más adelante te puedo ayudar a conectar con una IA real para respuestas más precisas.';

function getSpanishVoice() {
  const voices = window.speechSynthesis.getVoices();
  const spanishVoice = voices.find((voice) => voice.lang.toLowerCase().startsWith('es'));
  return spanishVoice || voices[0] || null;
}

function speak(text, options = {}) {
  if (!('speechSynthesis' in window)) {
    alert('Tu navegador no soporta síntesis de voz. Usa Chrome o Edge.');
    return;
  }

  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = 'es-ES';
  utterance.voice = getSpanishVoice();
  utterance.pitch = options.pitch ?? 1.05;
  utterance.rate = options.rate ?? 0.95;
  utterance.volume = options.volume ?? 1;
  window.speechSynthesis.cancel();
  window.speechSynthesis.speak(utterance);
}

function speakAsync(text, options = {}) {
  if (!('speechSynthesis' in window)) {
    return Promise.resolve();
  }

  return new Promise((resolve) => {
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'es-ES';
    utterance.voice = getSpanishVoice();
    utterance.pitch = options.pitch ?? 1.05;
    utterance.rate = options.rate ?? 0.95;
    utterance.volume = options.volume ?? 1;
    utterance.addEventListener('end', () => resolve());
    utterance.addEventListener('error', () => resolve());
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(utterance);
  });
}

function beep() {
  const AudioContext = window.AudioContext || window.webkitAudioContext;
  if (!AudioContext) {
    return;
  }

  const context = new AudioContext();
  const oscillator = context.createOscillator();
  const gainNode = context.createGain();

  oscillator.type = 'sine';
  oscillator.frequency.value = 520;
  gainNode.gain.value = 0.1;

  oscillator.connect(gainNode);
  gainNode.connect(context.destination);

  oscillator.start();
  oscillator.stop(context.currentTime + 0.15);
  oscillator.onended = () => {
    gainNode.disconnect();
    oscillator.disconnect();
    context.close();
  };
}

async function fetchAIAnswer(question) {
  const apiKey = 'AIzaSyC1VaizWF-wSazEsJTmLQTLrfOkkukRsFQ';
  const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${apiKey}`;

  try {
    const prompt = `Eres un agente de voz experto en recetas de cocina. Responde de manera clara, concisa y amigable, con un tono conversacional natural, ideal para ser escuchado en un audio. No uses formato markdown (como asteriscos, negritas o listas con guiones) para que la lectura de voz sea fluida. Si te preguntan algo que no es de cocina, responde amablemente que eres un asistente de cocina. La pregunta del usuario es: ${question}`;
    
    const response = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [{ parts: [{ text: prompt }] }]
      })
    });

    if (!response.ok) {
      throw new Error('Error en el servidor de IA de Gemini');
    }

    const data = await response.json();
    if (data.candidates && data.candidates.length > 0) {
      return data.candidates[0].content.parts[0].text;
    }
    return null;
  } catch (error) {
    console.error('IA error:', error);
    return null;
  }
}

async function processQuestion(text) {
  if (!text) {
    statusText.textContent = 'No se detectó pregunta. Habla nuevamente, por favor.';
    speakAsync('No se detectó tu pregunta. Intenta hablar de nuevo.');
    return;
  }

  questionField.value = text;
  statusText.textContent = 'He escuchado tu pregunta. Ahora la IA responde...';

  if (recognition && listening) {
    recognition.stop();
    updateControls(false);
  }

  isSpeaking = true;
  const aiResponse = await fetchAIAnswer(text);
  if (aiResponse) {
    statusText.textContent = 'Respondiendo con IA...';
    answerField.value = aiResponse;
    await speakAsync(aiResponse, { pitch: 1.05, rate: 0.95 });
  } else {
    const response = findRecipeResponse(text);
    statusText.textContent = 'No se pudo conectar con la IA, respondiendo con receta local...';
    answerField.value = response;
    await speakAsync(response, { pitch: 1.05, rate: 0.95 });
  }

  isSpeaking = false;
  if (sessionActive && !stopRequested) {
    startListening();
  }
}

function findRecipeResponse(text) {
  const match = recipes.find(item => item.trigger.test(text));
  return match ? match.response : defaultResponse;
}

let recognition;
let listening = false;
let sessionActive = false;
let stopRequested = false;
let isSpeaking = false;
const speechSupported = 'webkitSpeechRecognition' in window || 'SpeechRecognition' in window;
const secureHost = location.protocol === 'https:' || location.hostname === 'localhost' || location.hostname === '127.0.0.1';

function updateControls(active) {
  listening = active;
  startBtn.disabled = active;
  stopBtn.disabled = !active;
  if (active) {
    startBtn.classList.add('listening');
    statusCard.classList.add('listening');
  } else {
    startBtn.classList.remove('listening');
    statusCard.classList.remove('listening');
  }
}

function stopSession() {
  sessionActive = false;
  stopRequested = true;
  if (recognition && listening) {
    recognition.stop();
  }
  updateControls(false);
  statusText.textContent = 'Sesión finalizada. Presiona iniciar voz cuando quieras otra receta.';
  speakAsync('Perfecto, cuando quieras otra receta solo dilo.');
}

function startListening() {
  if (!recognition || listening) return;
  statusText.textContent = 'Escuchando tu pregunta... habla ahora.';
  updateControls(true);
  recognition.start();
}

if (speechSupported && secureHost) {
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  recognition = new SpeechRecognition();
  recognition.lang = 'es-ES';
  recognition.interimResults = false;
  recognition.maxAlternatives = 1;
  recognition.continuous = true;

  recognition.addEventListener('result', (event) => {
    const spokenText = event.results[event.results.length - 1][0].transcript;
    if (/\b(terminar|termina|basta|salir|stop)\b/i.test(spokenText)) {
      stopSession();
      return;
    }

    if (!isSpeaking) {
      processQuestion(spokenText);
    }
  });

  recognition.addEventListener('end', () => {
    updateControls(false);
    if (sessionActive && !stopRequested && !isSpeaking) {
      setTimeout(() => {
        if (sessionActive && !isSpeaking) {
          startListening();
        }
      }, 600);
    }
  });

  recognition.addEventListener('error', (event) => {
    updateControls(false);
    statusText.textContent = 'Error de reconocimiento de voz: ' + event.error;
    speakAsync('No pude reconocer tu voz, intenta de nuevo.');
  });
} else {
  const reason = !speechSupported
    ? 'Tu navegador no soporta reconocimiento de voz.'
    : 'SpeechRecognition requiere HTTPS o localhost para funcionar.';
  statusText.textContent = `${reason} Usa Chrome o Edge en un origen seguro.`;
  startBtn.disabled = true;
}

startBtn.addEventListener('click', async () => {
  if (recognition && !sessionActive) {
    sessionActive = true;
    stopRequested = false;
    statusText.textContent = 'Preparando para escuchar...';
    beep();
    await speakAsync('Hola, ¿qué quieres preparar el día de hoy?');
    startListening();
  }
});

stopBtn.addEventListener('click', () => {
  stopSession();
});

answerField.value = '';
statusText.textContent = 'Pulsa "Iniciar voz" y habla tu receta cuando escuches el mensaje.';
