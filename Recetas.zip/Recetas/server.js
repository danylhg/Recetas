import express from 'express';
import cors from 'cors';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import OpenAI from 'openai';

dotenv.config();

const app = express();
const port = process.env.PORT || 3000;
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

app.use(cors());
app.use(express.json());
app.use(express.static(__dirname));

const apiKey = process.env.OPENAI_API_KEY;
const openai = apiKey ? new OpenAI({ apiKey }) : null;

app.post('/api/ask', async (req, res) => {
  const { question } = req.body;

  if (!question) {
    return res.status(400).json({ error: 'La pregunta es obligatoria.' });
  }

  if (!apiKey) {
    return res.status(500).json({ error: 'Falta la variable OPENAI_API_KEY en .env.' });
  }

  try {
    const prompt = `Eres un asistente experto en recetas de cocina. Responde en español de forma clara y práctica, explicando los ingredientes, tiempos y pasos en orden. Da la receta paso a paso para que alguien que cocina por primera vez pueda seguirla. Pregunta: ${question}`;
    const response = await openai.responses.create({
      model: 'gpt-4.1-mini',
      temperature: 0.7,
      input: prompt
    });

    const answer = response.output
      .map(item => item.content?.map(part => part.text || '').join('') || '')
      .join('')
      .trim();

    res.json({ answer: answer || 'No se recibió respuesta de la IA.' });
  } catch (error) {
    console.error('OpenAI error:', error);
    res.status(500).json({ error: 'Error al procesar la pregunta con la IA.' });
  }
});

app.listen(port, () => {
  console.log(`Servidor iniciado en http://localhost:${port}`);
});
