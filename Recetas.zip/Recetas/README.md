# Agente de Voz de Recetas

Este proyecto es una página web de recetas habladas que puede usar reconocimiento de voz y conectar con OpenAI para respuestas más completas.

## Ejecución local

1. Instala dependencias:

```bash
npm install
```

2. Crea un archivo `.env` basado en `.env.example` y agrega tu clave de OpenAI:

```bash
copy .env.example .env
```

3. Ejecuta el servidor:

```bash
npm start
```

4. Abre en el navegador:

```text
http://localhost:3000
```

## Uso

- Presiona **Iniciar voz** para hablar tu pregunta de cocina.
- También puedes escribir tu pregunta y pulsar **Enviar pregunta**.
- Marca **Usar IA real** para obtener respuestas de OpenAI.

## Requisitos

- Navegador compatible con `SpeechRecognition` y `speechSynthesis` (Chrome o Edge).
- Clave de OpenAI en `.env`.
