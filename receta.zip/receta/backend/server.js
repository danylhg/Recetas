import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import axios from "axios";
import { GoogleGenAI } from "@google/genai";

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
});

let historial = [];

app.post("/api/chefia", async (req, res) => {
  try {
    const { mensaje } = req.body;

    historial.push(`Usuario: ${mensaje}`);

    const prompt = `
Eres ChefIA.

Responde corto.
Haz una sola pregunta.
Guía paso a paso.

${historial.join("\n")}
`;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-lite",
      contents: prompt,
    });

    const respuesta = response.text;

    historial.push(`ChefIA: ${respuesta}`);

    res.json({ respuesta });

  } catch (error) {
    console.log("ERROR GEMINI");

    res.json({
      respuesta: "Vamos a cocinar algo sencillo. ¿Quieres pasta o huevo?"
    });
  }
});

app.post("/api/voz", async (req, res) => {
  try {
    const { texto } = req.body;

    const response = await axios.post(
      "https://api.inworld.ai/tts/v1/voice",
      {
        text: texto,
        voiceId: process.env.INWORLD_VOICE_ID,
        modelId: "inworld-tts-1",
        audioConfig: {
          audioEncoding: "MP3",
          sampleRateHertz: 24000
        }
      },
      {
        headers: {
          Authorization: `Basic ${process.env.INWORLD_API_KEY}`,
          "Content-Type": "application/json"
        }
      }
    );

    const audioBuffer = Buffer.from(response.data.audioContent, "base64");

    res.setHeader("Content-Type", "audio/mpeg");
    res.send(audioBuffer);

  } catch (error) {
    console.log("ERROR VOZ");

    res.status(500).json({
      error: "No se pudo generar la voz"
    });
  }
});

app.listen(3000, () => {
  console.log("Servidor activo en http://localhost:3000");
});