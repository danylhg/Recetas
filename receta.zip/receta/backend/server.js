import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import axios from "axios";
import { GoogleGenAI } from "@google/genai";

dotenv.config();

const app = express();

app.use(cors());
app.use(express.json());

const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
});

let historial = [];

app.post("/api/chefia", async (req, res) => {
  try {
    const { mensaje } = req.body;

    if (!mensaje) {
      return res.status(400).json({
        error: "No se recibió mensaje.",
      });
    }

    historial.push({
      rol: "Usuario",
      texto: mensaje,
    });

    const historialTexto = historial
      .map((m) => `${m.rol}: ${m.texto}`)
      .join("\n");

    const prompt = `
Eres ChefIA, una asistente de cocina por voz.

Actúa como una conversación real.
No des toda la receta de golpe.

Reglas:
- Responde máximo en 2 frases.
- Haz solo una pregunta por turno.
- No expliques de más.
- Si el usuario dice qué quiere preparar, responde con los ingredientes necesarios.
- Pregunta si tiene esos ingredientes.
- Si dice que sí, da solo el primer paso.
- Si dice "listo", continúa con el siguiente paso.
- Si dice que no tiene algo, ofrece sustituciones.
- Si pide cambiar algo, adapta la receta.
- Habla como asistente de cocina, no como artículo.

Historial:
${historialTexto}

Mensaje actual del usuario:
${mensaje}
`;

    const response = await ai.models.generateContent({
      model: "gemini-2.0-flash",
      contents: prompt,
    });

    const respuesta = response.text;

    historial.push({
      rol: "ChefIA",
      texto: respuesta,
    });

    res.json({
      respuesta,
    });
  } catch (error) {
    console.error("ERROR GEMINI:", error);

    let mensajeError =
      "No pude consultar la IA en este momento. Intenta nuevamente más tarde.";

    const errorTexto = JSON.stringify(error);

    if (
      errorTexto.includes("RESOURCE_EXHAUSTED") ||
      errorTexto.includes("Quota exceeded") ||
      errorTexto.includes("429")
    ) {
      mensajeError =
        "Se agotó temporalmente la cuota de Gemini. Intenta más tarde o cambia de API key.";
    }

    res.status(500).json({
      error: mensajeError,
    });
  }
});

app.post("/api/voz", async (req, res) => {
  try {
    const { texto } = req.body;

    if (!texto) {
      return res.status(400).json({
        error: "No se recibió texto.",
      });
    }

    if (!process.env.ELEVENLABS_API_KEY) {
      return res.status(500).json({
        error: "Falta ELEVENLABS_API_KEY en .env",
      });
    }

    if (!process.env.ELEVENLABS_VOICE_ID) {
      return res.status(500).json({
        error: "Falta ELEVENLABS_VOICE_ID en .env",
      });
    }

    const voiceId = process.env.ELEVENLABS_VOICE_ID;

    const response = await axios.post(
      `https://api.elevenlabs.io/v1/text-to-speech/${voiceId}`,
      {
        text: texto,
        model_id: "eleven_multilingual_v2",
        voice_settings: {
          stability: 0.45,
          similarity_boost: 0.85,
          style: 0.35,
          use_speaker_boost: true,
        },
      },
      {
        headers: {
          "xi-api-key": process.env.ELEVENLABS_API_KEY,
          "Content-Type": "application/json",
          Accept: "audio/mpeg",
        },
        responseType: "arraybuffer",
        validateStatus: () => true,
      }
    );

    if (response.status !== 200) {
      const errorText = Buffer.from(response.data).toString("utf8");

      console.error("ERROR ELEVENLABS REAL:", errorText);

      return res.status(500).json({
        error: "No se pudo generar la voz con ElevenLabs.",
      });
    }

    res.setHeader("Content-Type", "audio/mpeg");
    res.send(Buffer.from(response.data));
  } catch (error) {
    console.error("ERROR ELEVENLABS:", error.message);

    res.status(500).json({
      error: "Error al generar voz.",
    });
  }
});

app.post("/api/reiniciar", (req, res) => {
  historial = [];

  res.json({
    ok: true,
    mensaje: "Conversación reiniciada.",
  });
});

app.get("/", (req, res) => {
  res.send("Backend de ChefIA activo.");
});

app.listen(3000, () => {
  console.log("Servidor activo en http://localhost:3000");
});