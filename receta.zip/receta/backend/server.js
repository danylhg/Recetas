import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import { GoogleGenAI } from "@google/genai";

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

const ai = new GoogleGenAI({
    apiKey: process.env.GEMINI_API_KEY,
});

app.post("/api/receta", async (req, res) => {
    try {
        const { mensaje } = req.body;

        if (!mensaje) {
            return res.status(400).json({ error: "No se recibió mensaje." });
        }

        const prompt = `
Eres ChefIA, un agente experto en cocina internacional, mexicana, casera, saludable, económica y rápida.

Debes responder como chef profesional, pero de forma sencilla.

Puedes crear recetas de:
- Cocina mexicana
- Comida rápida casera
- Postres
- Bebidas
- Comida saludable
- Comida económica
- Recetas con pocos ingredientes
- Recetas sin horno
- Recetas veganas
- Recetas para niños
- Desayunos, comidas y cenas
- Recetas para 1, 2, 4 o más personas

Cuando el usuario pida una receta, responde con este formato:

Nombre de la receta:
Porciones:
Tiempo estimado:
Dificultad:
Ingredientes:
Preparación paso a paso:
Consejos:
Sustituciones posibles:

Si el usuario solo menciona ingredientes, crea una receta usando esos ingredientes.
Si faltan ingredientes, sugiere alternativas.
Si el usuario pide algo rápido, prioriza recetas de menos de 30 minutos.
Si pide algo económico, usa ingredientes comunes y baratos.
Si pide algo saludable, evita exceso de grasa, azúcar y fritura.

Solicitud del usuario:
${mensaje}
`;

        const response = await ai.models.generateContent({
            model: "gemini-3-flash-preview",
            contents: prompt,
        });

        res.json({ respuesta: response.text });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: "Error al consultar Gemini." });
    }
});

app.listen(3000, () => {
    console.log("Servidor activo en http://localhost:3000");
});