const btn = document.getElementById("btnHablar");
const textoUsuario = document.getElementById("textoUsuario");
const respuestaIA = document.getElementById("respuestaIA");

const API = "http://localhost:3000/api/receta";

const SpeechRecognition =
    window.SpeechRecognition || window.webkitSpeechRecognition;

if (!SpeechRecognition) {
    respuestaIA.textContent =
        "Tu navegador no soporta reconocimiento de voz. Usa Google Chrome.";
}

const recognition = SpeechRecognition ? new SpeechRecognition() : null;

if (recognition) {
    recognition.lang = "es-MX";
    recognition.continuous = false;
    recognition.interimResults = false;
}

btn.addEventListener("click", () => {
    if (!recognition) return;

    textoUsuario.textContent = "Escuchando...";
    respuestaIA.textContent = "Procesando solicitud...";
    recognition.start();
});

if (recognition) {
    recognition.onresult = async (event) => {
        const texto = event.results[0][0].transcript;
        await enviarTexto(texto);
    };

    recognition.onerror = () => {
        textoUsuario.textContent = "No se pudo reconocer la voz. Intenta de nuevo.";
        respuestaIA.textContent = "Presiona nuevamente el botón y habla claro.";
    };
}

async function enviarTexto(texto) {
    textoUsuario.textContent = texto;
    respuestaIA.textContent = "Buscando receta...";

    try {
        const res = await fetch(API, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify({ mensaje: texto }),
        });

        const data = await res.json();

        if (!res.ok || data.error) {
            respuestaIA.textContent = data.error || "Ocurrió un error al consultar la IA.";
            return;
        }

        respuestaIA.textContent = data.respuesta;
        hablar(data.respuesta);
    } catch (error) {
        respuestaIA.textContent =
            "No se pudo conectar con el servidor. Verifica que el backend esté encendido.";
        console.error(error);
    }
}

function hablar(texto) {
    speechSynthesis.cancel();

    const speech = new SpeechSynthesisUtterance(texto);
    speech.lang = "es-MX";
    speech.rate = 1;
    speech.pitch = 1;

    speechSynthesis.speak(speech);
}