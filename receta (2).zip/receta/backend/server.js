import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import axios from "axios";
import { GoogleGenAI } from "@google/genai";

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
});

let historial = [];

app.post("/api/chefia", async (req, res) => {
  try {
    const { mensaje } = req.body;

    if (!mensaje) {
      return res.status(400).json({ error: "No se recibió mensaje." });
    }

    historial.push(`Usuario: ${mensaje}`);

    const prompt = `
Eres una asistente de cocina por voz.

Reglas:
- Responde corto. 
- Usa máximo 2 frases.
- Haz una sola pregunta por turno.
- No des toda la receta de golpe.
- Primero confirma ingredientes.
- Después guía paso a paso.
- Si el usuario dice "listo", continúa.
- Si falta algo, sugiere sustitución.

Conversación:
${historial.join("\n")}
`;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-lite",
      contents: prompt,
    });

    const respuesta = response.text;

    historial.push(`ChefIA: ${respuesta}`);

    res.json({ respuesta });
  } catch (error) {
    console.error("ERROR GEMINI:", error.message);

    res.json({
      respuesta:
        "Tuve un problema con la IA. Podemos seguir con una receta sencilla. ¿Quieres pasta, huevo o pollo?",
    });
  }
});

app.post("/api/voz", async (req, res) => {
  try {
    const { texto } = req.body;

    if (!texto) {
      return res.status(400).json({ error: "No se recibió texto." });
    }

    if (!process.env.INWORLD_API_KEY) {
      return res.status(500).json({ error: "Falta INWORLD_API_KEY en .env" });
    }

    if (!process.env.INWORLD_VOICE_ID) {
      return res.status(500).json({ error: "Falta INWORLD_VOICE_ID en .env" });
    }

    const response = await axios.post(
      "https://api.inworld.ai/tts/v1/voice",
      {
        text: texto,
        voiceId: process.env.INWORLD_VOICE_ID,
        modelId: process.env.INWORLD_MODEL_ID || "inworld-tts-1",
        audioConfig: {
          audioEncoding: "MP3",
          sampleRateHertz: 24000,
        },
      },
      {
        headers: {
          Authorization: `Basic ${process.env.INWORLD_API_KEY}`,
          "Content-Type": "application/json",
        },
        validateStatus: () => true,
      }
    );

    if (response.status !== 200) {
      console.error("ERROR INWORLD REAL:", response.data);

      return res.status(500).json({
        error: "No se pudo generar la voz con Inworld.",
      });
    }

    const audioBuffer = Buffer.from(response.data.audioContent, "base64");

    res.setHeader("Content-Type", "audio/mpeg");
    res.send(audioBuffer);
  } catch (error) {
    console.error("ERROR INWORLD:", error.message);

    res.status(500).json({
      error: "Error al generar voz con Inworld.",
    });
  }
});

app.post("/api/reiniciar", (req, res) => {
  historial = [];
  res.json({ ok: true, mensaje: "Conversación reiniciada." });
});

app.get("/", (req, res) => {
  res.send("Backend de ChefIA activo.");
});

app.listen(3000, () => {
  console.log("Servidor activo en http://localhost:3000");
});